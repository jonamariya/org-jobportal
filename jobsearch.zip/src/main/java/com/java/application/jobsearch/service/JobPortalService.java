package com.java.application.jobsearch.service;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
@ApplicationPath("")
public class JobPortalService extends Application {

}
