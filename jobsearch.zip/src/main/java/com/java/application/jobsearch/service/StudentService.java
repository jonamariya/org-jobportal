package com.java.application.jobsearch.service;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.java.application.jobsearch.GenericDAO;
import com.java.application.jobsearch.dto.StudentDetails;

@Path("/students")
public class StudentService {

	ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
	GenericDAO dao=context.getBean("genericDAO",GenericDAO.class);
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Transactional
	public String getProfileData(){		
		System.out.println(dao.getCount());
		return ("getting Profiledata in JobPortalService");
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String postProfileData(){
		dao.save();
		return ("posting Profiledata in JobPortalService");
	}

	
}
