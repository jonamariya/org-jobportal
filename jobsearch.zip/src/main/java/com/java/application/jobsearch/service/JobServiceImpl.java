package com.java.application.jobsearch.service;

import java.util.List;
import java.util.Map;


import com.java.application.jobsearch.GenericDAOService;
import com.java.application.jobsearch.dto.EmployerDetails;
import com.java.application.jobsearch.dto.JobDetails;

public class JobServiceImpl implements JobService{

	private GenericDAOService genericDAOService;
	public GenericDAOService getGenericDAOService() {
		return genericDAOService;
	}

	public void setGenericDAOService(GenericDAOService genericDAOService) {
		this.genericDAOService = genericDAOService;
	}

	@Override
	public List<JobDetails> getAllJobs(int empId) {
		EmployerDetails emp=(EmployerDetails) genericDAOService.get(EmployerDetails.class, empId);
		List<JobDetails> jobList = (List<JobDetails>) emp.getJobList();
		return jobList;
	}

	@Override
	public JobDetails getJobById(int empId, int jobId) {
		EmployerDetails emp=(EmployerDetails) genericDAOService.get(EmployerDetails.class, empId);
		List<JobDetails> jobList = (List<JobDetails>) emp.getJobList();
		JobDetails newJob =  (JobDetails) jobList.get(jobId);
		return newJob;
	}

	@Override
	public void createJob(int empId,JobDetails job) {
		EmployerDetails emp=(EmployerDetails) genericDAOService.get(EmployerDetails.class, empId);
		List<JobDetails> jobList = (List<JobDetails>) emp.getJobList();
		jobList.add(job);
		emp.setJobList(jobList);
		genericDAOService.save(emp);
			
	}
}
