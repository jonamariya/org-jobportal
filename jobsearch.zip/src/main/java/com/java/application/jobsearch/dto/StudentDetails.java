package com.java.application.jobsearch.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="STUDENT_DETAILS")
public class StudentDetails {
	@Id @GeneratedValue
	@Column(name="STUDENT_ID")
	private int studentId;
	@Column(name="FIRSTNAME")
	private String firstName;
	public StudentDetails(){}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
}
