package com.java.application.jobsearch.resource;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
@ApplicationPath("")
public class JobPortalService extends Application {

}
