package com.java.application.jobsearch.service;

import java.util.List;

import com.java.application.jobsearch.dto.JobDetails;

public interface JobService {
	public List<JobDetails> getAllJobs(int empId);
	public JobDetails getJobById(int empId,int jobId);
	public void createJob(int empId,JobDetails profile);
}
