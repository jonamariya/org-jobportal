package com.java.application.jobsearch;

import javax.annotation.Resource;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.java.application.jobsearch.dto.StudentDetails;

@Repository
public class GenericDAO {
	@Autowired
	@Resource(name="sessionFactory")
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void save(){
		StudentDetails student = new StudentDetails();
		student.setFirstName("leni");
		if(getSessionFactory()!=null){
		try{
		Session session = getSessionFactory().getCurrentSession();
		session.save(student);
		}catch(HibernateException he){
			he.printStackTrace();
		}
		
		}else
			System.out.println("session factory is null");
	}
	
	public String getCount(){
		Query query=getSessionFactory().openSession().createQuery("select count(*) from StudentDetails");
		return (query.uniqueResult().toString());
	}
}
