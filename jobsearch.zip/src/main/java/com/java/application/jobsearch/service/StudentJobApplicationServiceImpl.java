package com.java.application.jobsearch.service;

import java.util.List;

import javax.validation.ConstraintViolationException;

import com.java.application.jobsearch.GenericDAOService;
import com.java.application.jobsearch.dto.StudentDetails;

public class StudentJobApplicationServiceImpl implements StudentJobApplicationService {

	private GenericDAOService genericDAOService;
	public GenericDAOService getGenericDAOService() {
		return genericDAOService;
	}

	public void setGenericDAOService(GenericDAOService genericDAOService) {
		this.genericDAOService = genericDAOService;
	}

	@Override
	public List<StudentDetails> getAllProfiles() {
		List<StudentDetails> studentList = (List<StudentDetails>) genericDAOService.get(StudentDetails.class);
		return studentList;
	}

	@Override
	public StudentDetails getProfileById(int profileId) {
		StudentDetails newStudent = (StudentDetails) genericDAOService.get(StudentDetails.class, profileId);
		return newStudent;
	}

	@Override
	public void createProfile(StudentDetails profile) {
		
			genericDAOService.save(profile);
			
	}

}
